<template>
  <div class="dashboard-container">
    <el-card class="box-card">
      <div class="action-view mb20">
        <div>订单管理</div>
        <el-button type="primary" icon="el-icon-plus">搜索</el-button>
      </div>
      <div class="table-view mb20">
        <el-table :data="tableData" border>
          <el-table-column label="#" width="30" />
          <el-table-column label="订单编号" prop="order_number" />
          <el-table-column label="订单价格" prop="order_id" />
          <el-table-column label="是否付款" prop="pay_status" />
          <el-table-column label="是否发货" prop="is_send" />
          <el-table-column label="下单时间" prop="create_time" />
          <el-table-column label="操作" width="200">
            <template>
              <el-button type="text">修改地址</el-button>
              <el-button type="text">查看物流</el-button>
            </template>

          </el-table-column>
        </el-table>
      </div>
      <!-- 分页区域 默认分页10条一页-->
      <div class="page-view fc">
        <!-- 分页器 -->
        <el-pagination
          background
          layout="prev, pager, next"
          :total="pagable.total"
          :current-page="pagable.page"
          @current-change="pageChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script>
// import Axios from 'axios'
export default {
  data() {
    return {
      tableData: [],
      pagable: {
        // page: 1,
        // total: 0
        // 页码
        page: 1,
        // 每页条数
        pagesize: 10,
        // 总条数
        total: 0
      },
      value1: true,
      // 表单数据【新增】
      formInput: {}
    }
  },
  mounted() {
    this.getTableData()
  },
  methods: {
    // 获取表格数据
    async getTableData() {
      const { page } = this.pagable
      const { data } = await this.$http.get('/orders', { params: { total: 1, pagenum: page, pagesize: 10 }})
      console.log(data)
      const res = data.goods
      this.tableData = res
      this.pagable.total = data.total
      // console.log(res)
    },
    pageChange(page) {
      this.pagable.page = page
      // console.log(page)
      this.getTableData()
    }
  }
}
</script>

<style lang="scss" scoped>
.mb20{
  div{
    margin-bottom: 15px;
  }
}

</style>
