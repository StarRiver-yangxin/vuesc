<template>
  <div class="dashboard-container">
    <h1>欢迎回来</h1>
  </div>
</template>

<script>

export default {
}
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
</style>
